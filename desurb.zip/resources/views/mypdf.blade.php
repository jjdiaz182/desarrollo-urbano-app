<!DOCTYPE html>
<html>
<head>
    <title>Visto Bueno</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
    
</head>
<body>
    <h1>{{ $propietario }}</h1>
    <p class="text-lg text-green-600">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
    tempor incididunt ut labore et dolore magna aliqua.</p>
  
    <script src="https://cdn.tailwindcss.com"></script>
</body>
</html>
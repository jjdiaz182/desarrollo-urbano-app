<div class="w-18 h-16">

    <img src="https://serviciospublicos.morelia.gob.mx/wp-content/uploads/2023/07/Recurso-12.png" alt="Logo de Grupo Herso" class="w-full h-full object-contain">

</div>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Desarrollos')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="pt-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-xl sm:rounded-lg ">
                <div class="px-4">
                    <div class="bg-white my-4 mx-4">
                       
                        <div>
                            
                            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 py-6">
                                <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-6">
                                    <div class="flex justify-between items-center mb-4">
                                        <h1 class="text-2xl font-semibold">Desarrollos de <?php echo e($empresa->nombre); ?></h1>
                                        <a href="<?php echo e(route('desarrollos.create', $empresa)); ?>" class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">
                                            Agregar Desarrollo
                                        </a>
                                    </div>
                            
                                    <?php if(session('success')): ?>
                                        <div class="p-4 mb-4 text-green-800 bg-green-100 rounded-lg">
                                            <?php echo e(session('success')); ?>

                                        </div>
                                    <?php endif; ?>
                            
                                    <table class="w-full border border-gray-200 rounded-md">
                                        <thead>
                                            <tr class="bg-gray-100 text-left">
                                                <th class="py-2 px-4 border">Nombre</th>
                                                <th class="py-2 px-4 border">Alias</th>
                                                <th class="py-2 px-4 border">Tipo</th>
                                                <th class="py-2 px-4 border">Número de Viviendas</th>
                                                <th class="py-2 px-4 border">Tipo de Vivienda</th>
                                                <th class="py-2 px-4 border">Ubicación</th>
                                                <th class="py-2 px-4 border">Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $desarrollos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desarrollo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr class="border-t hover:bg-gray-50">
                                                    <td class="py-2 px-4 border"><?php echo e($desarrollo->nombre); ?></td>
                                                    <td class="py-2 px-4 border"><?php echo e($desarrollo->alias); ?></td>
                                                    <td class="py-2 px-4 border"><?php echo e($desarrollo->tipo_desarrollo); ?></td>
                                                    <td class="py-2 px-4 border"><?php echo e($desarrollo->numero_viviendas); ?></td>
                                                    <td class="py-2 px-4 border"><?php echo e($desarrollo->tipo_vivienda); ?></td>
                                                    <td class="py-2 px-4 border"><?php echo e($desarrollo->municipio); ?>, <?php echo e($desarrollo->estado); ?>, <?php echo e($desarrollo->pais); ?></td>
                                                    <td class="py-2 px-4 border">
                                                        <div class="flex flex-col gap-2 w-full">
                                                            <a href="<?php echo e(route('desarrollos.edit', [$empresa, $desarrollo])); ?>" 
                                                               class="w-full px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600 text-sm text-center">
                                                                Editar
                                                            </a>
                                                    
                                                            <form action="<?php echo e(route('desarrollos.destroy', [$empresa, $desarrollo])); ?>" method="POST" class="w-full">
                                                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                                <button type="submit" class="w-full px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600 text-sm"
                                                                    onclick="return confirm('¿Seguro que deseas eliminar este desarrollo?')">
                                                                    Eliminar
                                                                </button>
                                                            </form>
                                                    
                                                            <a href="<?php echo e(route('visto-bueno.index', ['desarrollo' => $desarrollo->id])); ?>" 
                                                               class="w-full px-3 py-1 bg-yellow-500 text-white rounded hover:bg-yellow-600 text-sm text-center">
                                                                Visto Bueno
                                                            </a>
                                                        </div>
                                                    </td>
                                                    
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                            
                                </div>
                            </div>

                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\norozco\Downloads\Laravel\DesarrolloUrbano\resources\views/desarrollos/index.blade.php ENDPATH**/ ?>
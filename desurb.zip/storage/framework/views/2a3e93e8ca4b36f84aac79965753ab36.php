<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Documento PDF</title>
    <style>
        /* Añadir estilos para el PDF aquí si es necesario */
        body {
            font-family: Arial, sans-serif;
        }
    </style>
</head>
<body>
    <p> Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum laborum molestiae, magni mollitia ipsa id veniam in necessitatibus hic, aliquam, voluptatem ea repellendus sint modi dignissimos. Ipsa beatae hic at. </p>
    <!-- Más contenido según el formato del documento -->
</body>
</html><?php /**PATH C:\Users\norozco\Downloads\Laravel\DesarrolloUrbano\resources\views/livewire/document-pdf.blade.php ENDPATH**/ ?>
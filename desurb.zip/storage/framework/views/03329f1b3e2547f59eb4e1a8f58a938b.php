<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Editar Empresa')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="pt-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-xl sm:rounded-lg ">
                <div class="px-4">
                    <div class="bg-white my-4 mx-4">
                       
                        <div>

                            <div class="max-w-4xl mx-auto sm:px-6 lg:px-8 py-6">
                                <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-6">
                                    <h1 class="text-2xl font-semibold mb-4">Editar Desarrollo</h1>
                            
                                    <?php if($errors->any()): ?>
                                        <div class="mb-4 p-4 text-red-800 bg-red-100 rounded-lg">
                                            <ul>
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    <?php endif; ?>
                            
                                    <form action="<?php echo e(route('desarrollos.update', ['empresa' => $empresa->id, 'desarrollo' => $desarrollo->id])); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                            
                                        <div class="grid grid-cols-2 gap-4">
                                            <div>
                                                <label class="block font-medium text-gray-700">Nombre</label>
                                                <input type="text" name="nombre" value="<?php echo e(old('nombre', $desarrollo->nombre)); ?>" required 
                                                    class="w-full px-4 py-2 border rounded-md focus:ring focus:ring-blue-300">
                                            </div>
                            
                                            <div>
                                                <label class="block font-medium text-gray-700">Alias</label>
                                                <input type="text" name="alias" value="<?php echo e(old('alias', $desarrollo->alias)); ?>" 
                                                    class="w-full px-4 py-2 border rounded-md focus:ring focus:ring-blue-300">
                                            </div>
                            
                                            <div>
                                                <label class="block font-medium text-gray-700">Tipo de Desarrollo</label>
                                                <input type="text" name="tipo_desarrollo" value="<?php echo e(old('tipo_desarrollo', $desarrollo->tipo_desarrollo)); ?>" required 
                                                    class="w-full px-4 py-2 border rounded-md focus:ring focus:ring-blue-300">
                                            </div>
                            
                                            <div>
                                                <label class="block font-medium text-gray-700">Número de Viviendas</label>
                                                <input type="number" name="numero_viviendas" value="<?php echo e(old('numero_viviendas', $desarrollo->numero_viviendas)); ?>" required 
                                                    class="w-full px-4 py-2 border rounded-md focus:ring focus:ring-blue-300">
                                            </div>
                            
                                            <div>
                                                <label class="block font-medium text-gray-700">Tipo de Vivienda</label>
                                                <select name="tipo_vivienda" required class="w-full px-4 py-2 border rounded-md focus:ring focus:ring-blue-300">
                                                    <option value="interes social" <?php echo e($desarrollo->tipo_vivienda == 'interes social' ? 'selected' : ''); ?>>Interés Social</option>
                                                    <option value="medio residencial" <?php echo e($desarrollo->tipo_vivienda == 'medio residencial' ? 'selected' : ''); ?>>Medio Residencial</option>
                                                    <option value="residencial" <?php echo e($desarrollo->tipo_vivienda == 'residencial' ? 'selected' : ''); ?>>Residencial</option>
                                                </select>
                                            </div>
                            
                                            <div>
                                                <label class="block font-medium text-gray-700">País</label>
                                                <input type="text" name="pais" value="<?php echo e(old('pais', $desarrollo->pais)); ?>" required 
                                                    class="w-full px-4 py-2 border rounded-md focus:ring focus:ring-blue-300">
                                            </div>
                            
                                            <div>
                                                <label class="block font-medium text-gray-700">Estado</label>
                                                <input type="text" name="estado" value="<?php echo e(old('estado', $desarrollo->estado)); ?>" required 
                                                    class="w-full px-4 py-2 border rounded-md focus:ring focus:ring-blue-300">
                                            </div>
                            
                                            <div>
                                                <label class="block font-medium text-gray-700">Municipio</label>
                                                <input type="text" name="municipio" value="<?php echo e(old('municipio', $desarrollo->municipio)); ?>" required 
                                                    class="w-full px-4 py-2 border rounded-md focus:ring focus:ring-blue-300">
                                            </div>
                                        </div>
                            
                                        <div class="mt-6 flex gap-4">
                                            <button type="submit" class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">
                                                Actualizar
                                            </button>
                                            <a href="<?php echo e(route('desarrollos.index', ['empresa' => $empresa->id])); ?>" class="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600">
                                                Cancelar
                                            </a>
                                        </div>
                                    </form>
                                </div>
                            </div>

                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\norozco\Downloads\Laravel\DesarrolloUrbano\resources\views/desarrollos/edit.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Crear Apoderado Legal')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="pt-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-xl sm:rounded-lg ">
                <div class="px-4">
                    <div class="bg-white my-4 mx-4">
                       
                        <div>
                            
                            <div class="max-w-4xl mx-auto sm:px-6 lg:px-8 py-6">
                                <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-6">
                                    <h1 class="text-2xl font-semibold mb-4">Agregar Apoderado Legal para <?php echo e($empresa->nombre); ?></h1>

                                    <?php if($errors->any()): ?>
                                        <div class="mb-4 p-4 text-red-800 bg-red-100 rounded-lg">
                                            <ul>
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    <?php endif; ?>

                                    <form action="<?php echo e(route('apoderados.store', ['empresa' => $empresa->id])); ?>" method="POST">
                                        <?php echo csrf_field(); ?>

                                        <div class="grid grid-cols-2 gap-4">
                                            <div>
                                                <label class="block font-medium text-gray-700">Nombre Completo</label>
                                                <input type="text" name="nombre" value="<?php echo e(old('nombre')); ?>" required 
                                                    class="w-full px-4 py-2 border rounded-md focus:ring focus:ring-blue-300">
                                            </div>

                                            <div>
                                                <label class="block font-medium text-gray-700">Sexo</label>
                                                <select name="sexo" required class="w-full px-4 py-2 border rounded-md focus:ring focus:ring-blue-300">
                                                    <option value="Masculino">Masculino</option>
                                                    <option value="Femenino">Femenino</option>
                                                    <option value="Otro">Otro</option>
                                                </select>
                                            </div>

                                            <div>
                                                <label class="block font-medium text-gray-700">RFC</label>
                                                <input type="text" name="rfc" value="<?php echo e(old('rfc')); ?>" required 
                                                    class="w-full px-4 py-2 border rounded-md focus:ring focus:ring-blue-300">
                                            </div>

                                            <div>
                                                <label class="block font-medium text-gray-700">CURP</label>
                                                <input type="text" name="curp" value="<?php echo e(old('curp')); ?>" required 
                                                    class="w-full px-4 py-2 border rounded-md focus:ring focus:ring-blue-300">
                                            </div>

                                            <div>
                                                <label class="block font-medium text-gray-700">Prefijo</label>
                                                <input type="text" name="prefijo" value="<?php echo e(old('prefijo')); ?>" placeholder="Ej: Sr., Dra., Lic." 
                                                    class="w-full px-4 py-2 border rounded-md focus:ring focus:ring-blue-300">
                                            </div>

                                            <div>
                                                <label class="block font-medium text-gray-700">Título</label>
                                                <input type="text" name="titulo" value="<?php echo e(old('titulo')); ?>" placeholder="Ej: Abogado, Contador" 
                                                    class="w-full px-4 py-2 border rounded-md focus:ring focus:ring-blue-300">
                                            </div>

                                            <div>
                                                <label class="block font-medium text-gray-700">Cédula Profesional</label>
                                                <input type="text" name="cedula" value="<?php echo e(old('cedula')); ?>" 
                                                    class="w-full px-4 py-2 border rounded-md focus:ring focus:ring-blue-300">
                                            </div>

                                            <div>
                                                <label class="block font-medium text-gray-700">Teléfono</label>
                                                <input type="text" name="telefono" value="<?php echo e(old('telefono')); ?>" 
                                                    class="w-full px-4 py-2 border rounded-md focus:ring focus:ring-blue-300">
                                            </div>

                                            <div>
                                                <label class="block font-medium text-gray-700">Correo Electrónico</label>
                                                <input type="email" name="correo" value="<?php echo e(old('correo')); ?>" 
                                                    class="w-full px-4 py-2 border rounded-md focus:ring focus:ring-blue-300">
                                            </div>

                                            <div>
                                                <label class="block font-medium text-gray-700">Fecha de Nacimiento</label>
                                                <input type="date" name="fecha_nacimiento" value="<?php echo e(old('fecha_nacimiento')); ?>" 
                                                    class="w-full px-4 py-2 border rounded-md focus:ring focus:ring-blue-300">
                                            </div>

                                            <div class="col-span-2">
                                                <label class="block font-medium text-gray-700">Dirección</label>
                                                <textarea name="direccion" rows="3" class="w-full px-4 py-2 border rounded-md focus:ring focus:ring-blue-300"><?php echo e(old('direccion')); ?></textarea>
                                            </div>
                                        </div>

                                        <div class="mt-6 flex gap-4">
                                            <button type="submit" class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">
                                                Guardar
                                            </button>
                                            <a href="<?php echo e(route('apoderados.index', ['empresa' => $empresa->id])); ?>" 
                                            class="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600">
                                                Cancelar
                                            </a>
                                        </div>
                                    </form>
                                </div>
                            </div>
   

                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\norozco\Downloads\Laravel\DesarrolloUrbano\resources\views/apoderados/create.blade.php ENDPATH**/ ?>
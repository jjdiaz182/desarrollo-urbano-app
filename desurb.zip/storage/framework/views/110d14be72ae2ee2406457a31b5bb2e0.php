<a href="/">
    <div class="w-36 h-24">
        <img src="https://serviciospublicos.morelia.gob.mx/wp-content/uploads/2023/07/Recurso-12.png" alt="Logo de Grupo Herso" class="w-full h-full object-contain">
    </div>
        
</a>
<?php /**PATH C:\Users\norozco\Downloads\Laravel\DesarrolloUrbano\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>
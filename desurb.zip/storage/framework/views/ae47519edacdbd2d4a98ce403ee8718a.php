<!DOCTYPE html>
<html>
<head>
    <title>Laravel 11 Generate PDF Example - ItSolutionStuff.com</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
    
</head>
<body>
    <h1><?php echo e($propietario); ?></h1>
    <p class="text-lg text-green-600">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
    tempor incididunt ut labore et dolore magna aliqua.</p>
  
    <script src="https://cdn.tailwindcss.com"></script>
</body>
</html><?php /**PATH C:\Users\norozco\Downloads\Laravel\DesarrolloUrbano\resources\views/mypdf.blade.php ENDPATH**/ ?>